from __future__ import annotations
from typing import TYPE_CHECKING
import numpy as np

from .base import BaseEffect
from .registry import register_effect

if TYPE_CHECKING:
    from moviepy.video.VideoClip import VideoClip
    from PySide6.QtGui import QImage


@register_effect
class SepiaEffect(BaseEffect):
    key = "sepia"

    # ---------- MoviePy (Export) ----------
    def apply_moviepy(self, clip: "VideoClip") -> "VideoClip":
        def _sepia(img: np.ndarray) -> np.ndarray:
            # img shape (H, W, 3|4), dtype=uint8, channels RGB in MoviePy
            arr = img.astype(np.float32, copy=False)
            r = arr[..., 0]; g = arr[..., 1]; b = arr[..., 2]
            tr = 0.393 * r + 0.769 * g + 0.189 * b
            tg = 0.349 * r + 0.686 * g + 0.168 * b
            tb = 0.272 * r + 0.534 * g + 0.131 * b
            arr[..., 0] = np.clip(tr, 0, 255)
            arr[..., 1] = np.clip(tg, 0, 255)
            arr[..., 2] = np.clip(tb, 0, 255)
            return arr.astype(np.uint8, copy=False)
        return clip.fl_image(_sepia)

    # ---------- Preview (QImage) ----------
    def apply_qimage(self, img: "QImage") -> "QImage":
        from PySide6.QtGui import QImage
        # Sicheren, schreibbaren ARGB32-Puffer herstellen
        if img.format() != QImage.Format_ARGB32:
            img = img.convertToFormat(QImage.Format_ARGB32)
        else:
            img = img.copy()  # detach -> eigener, schreibbarer Speicher

        h, w = img.height(), img.width()
        ptr = img.bits()            # memoryview
        # In einen 1D-Bytes-View casten, dann ohne Kopie in ndarray „mappen“
        mv = memoryview(ptr).cast('B')
        arr = np.frombuffer(mv, dtype=np.uint8).reshape((h, w, 4))

        # BGRA → wir bearbeiten B,G,R (0,1,2)
        b = arr[..., 0].astype(np.float32, copy=False)
        g = arr[..., 1].astype(np.float32, copy=False)
        r = arr[..., 2].astype(np.float32, copy=False)

        tr = 0.393 * r + 0.769 * g + 0.189 * b
        tg = 0.349 * r + 0.686 * g + 0.168 * b
        tb = 0.272 * r + 0.534 * g + 0.131 * b

        arr[..., 2] = np.clip(tr, 0, 255).astype(np.uint8)  # R
        arr[..., 1] = np.clip(tg, 0, 255).astype(np.uint8)  # G
        arr[..., 0] = np.clip(tb, 0, 255).astype(np.uint8)  # B
        # Alpha bleibt unverändert (arr[..., 3])

        return img
