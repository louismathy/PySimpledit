from __future__ import annotations
from typing import TYPE_CHECKING
import numpy as np

from .base import BaseEffect
from .registry import register_effect

if TYPE_CHECKING:
    from moviepy.video.VideoClip import VideoClip
    from PySide6.QtGui import QImage


@register_effect
class ContrastEffect(BaseEffect):
    key = "contrast"

    def _factor(self) -> float:
        # Default +20% Kontrast; per params z.B. {"amount": 0.3}
        amt = float(self.params.get("amount", 0.2))
        return max(-0.99, amt) + 1.0

    # ---------- MoviePy (Export) ----------
    def apply_moviepy(self, clip: "VideoClip") -> "VideoClip":
        f = self._factor()
        mean = 127.5
        def _contrast(img: np.ndarray) -> np.ndarray:
            arr = img.astype(np.float32, copy=False)
            arr[..., :3] = (arr[..., :3] - mean) * f + mean
            np.clip(arr[..., :3], 0, 255, out=arr[..., :3])
            return arr.astype(np.uint8, copy=False)
        return clip.fl_image(_contrast)

    # ---------- Preview (QImage) ----------
    def apply_qimage(self, img: "QImage") -> "QImage":
        from PySide6.QtGui import QImage
        f = self._factor()
        mean = 127.5

        if img.format() != QImage.Format_ARGB32:
            img = img.convertToFormat(QImage.Format_ARGB32)
        else:
            img = img.copy()

        h, w = img.height(), img.width()
        mv = memoryview(img.bits()).cast('B')
        arr = np.frombuffer(mv, dtype=np.uint8).reshape((h, w, 4))

        # BGRA → 0,1,2
        arrf = arr[..., :3].astype(np.float32, copy=False)
        arrf[:] = (arrf - mean) * f + mean
        np.clip(arrf, 0, 255, out=arrf)
        arr[..., :3] = arrf.astype(np.uint8, copy=False)
        return img
