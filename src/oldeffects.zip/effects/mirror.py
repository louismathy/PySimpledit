from __future__ import annotations
from typing import TYPE_CHECKING
from .base import BaseEffect
from .registry import register_effect

if TYPE_CHECKING:
    from moviepy.video.VideoClip import VideoClip
    from PySide6.QtGui import QImage

@register_effect
class MirrorEffect(BaseEffect):
    """
    Horizontal mirror (flip).
    Params:
      horizontal: bool (default True)
      vertical: bool (default False)
    """
    key = "mirror"

    def apply_moviepy(self, clip: "VideoClip") -> "VideoClip":
        horiz = bool(self.params.get("horizontal", True))
        vert = bool(self.params.get("vertical", False))
        try:
            from moviepy.video.fx.all import mirror_x, mirror_y
            out = clip
            if horiz:
                out = mirror_x(out)
            if vert:
                out = mirror_y(out)
            return out
        except Exception:
            return clip.fx(lambda c: c)  # no-op fallback

    def apply_qimage(self, img: "QImage") -> "QImage":
        horiz = bool(self.params.get("horizontal", True))
        vert = bool(self.params.get("vertical", False))
        return img.mirrored(horiz, vert)
