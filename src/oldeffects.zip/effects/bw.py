from __future__ import annotations
from typing import TYPE_CHECKING
from .base import BaseEffect
from .registry import register_effect

if TYPE_CHECKING:
    from moviepy.video.VideoClip import VideoClip
    from PySide6.QtGui import QImage

@register_effect
class BWEffect(BaseEffect):
    """Simple grayscale (black & white) effect."""
    key = "bw"

    # MoviePy export side
    def apply_moviepy(self, clip: "VideoClip") -> "VideoClip":
        # MoviePy ships with a built-in blackwhite effect
        try:
            from moviepy.video.fx.all import blackwhite
            return blackwhite(clip)
        except Exception:
            # Fallback: return original clip if fx not available
            return clip

    # Preview side on QImage (fast, per-pixel desaturation)
    def apply_qimage(self, img: "QImage") -> "QImage":
        # Convert-in-place to grayscale to avoid copies if possible
        # Using Qt built-in conversion is fast enough for preview
        from PySide6.QtGui import QImage
        return img.convertToFormat(QImage.Format_Grayscale8)

# Optional: back-compat alias so old configs using "grayscale" keep working
@register_effect
class GrayscaleEffect(BWEffect):
    key = "grayscale"


