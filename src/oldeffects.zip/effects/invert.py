from __future__ import annotations
from typing import TYPE_CHECKING
from .base import BaseEffect
from .registry import register_effect

if TYPE_CHECKING:
    from moviepy.video.VideoClip import VideoClip
    from PySide6.QtGui import QImage

@register_effect
class InvertEffect(BaseEffect):
    key = "invert"

    def apply_moviepy(self, clip: "VideoClip") -> "VideoClip":
        try:
            from moviepy.video.fx.all import invert_colors
            return invert_colors(clip)
        except Exception:
            return clip

    def apply_qimage(self, img: "QImage") -> "QImage":
        from PySide6.QtGui import QImage
        img = img.convertToFormat(QImage.Format_ARGB32)
        img.invertPixels(QImage.InvertRgb)  # alpha bleibt erhalten
        return img
